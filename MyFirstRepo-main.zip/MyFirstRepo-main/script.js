function showMessage() {
    alert("Hello, GitHub!");
}

console.log("JavaScript is working!");
